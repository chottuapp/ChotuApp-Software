from pathlib import Path
import argparse
from rollback_responsive_ui import install
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--target',type=Path,default=Path.home()/'Desktop'/'ChotuApp_Software');args=p.parse_args()
 print('Smooth UI update withdrawn; removing only its previous hook.')
 install(args.target)
