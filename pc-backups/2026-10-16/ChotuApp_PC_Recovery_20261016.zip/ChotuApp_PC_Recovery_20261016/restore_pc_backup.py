"""Restore the reviewed PC snapshot without deleting existing exports or saved runs."""
import argparse,datetime,hashlib,json,os,shutil,tempfile
from pathlib import Path,PurePosixPath

ROOT=Path(__file__).resolve().parent

def safe_relative(name):
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or '\\' in name:raise RuntimeError('Unsafe backup entry: '+name)
    return Path(*p.parts)

def restore(desktop):
    desktop=Path(desktop).expanduser().resolve();manifest=json.loads((ROOT/'BACKUP_MANIFEST.json').read_text(encoding='utf-8'))
    payloads={}
    # Validate every byte before touching the user's installation.
    for name,record in manifest['files'].items():
        payload=(ROOT/safe_relative(name)).read_bytes()
        if len(payload)!=record['size'] or hashlib.sha256(payload).hexdigest()!=record['sha256']:raise RuntimeError('Backup integrity check failed: '+name)
        if name.endswith('.py'):compile(payload,name,'exec')
        payloads[name]=payload
    program=desktop/'ChotuApp_Software';program.mkdir(parents=True,exist_ok=True)
    backup=program/'backups'/('before_pc_restore_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    destinations={}
    for name,payload in payloads.items():
        relative=safe_relative(name);section=relative.parts[0];tail=Path(*relative.parts[1:])
        if section=='software':target=program/tail
        elif section=='settings':target=desktop/tail
        elif section=='exports':target=desktop/'ANAS_DATA_FETCH'/tail
        else:raise RuntimeError('Unexpected backup section')
        # Resolve portable template markers only at restoration time.
        if target.name in ('daily_automation.json','chotuapp_preferences.json'):
            config=json.loads(payload)
            config['template']=str(program/'Chotu_Products_Import_Template_Discount_Tags.xlsx')
            if target.name=='daily_automation.json':config.update(enabled=False,startup=False,inflight=None)
            payload=json.dumps(config,indent=2,ensure_ascii=False).encode('utf-8')
        if target in destinations:raise RuntimeError('Duplicate restore destination')
        destinations[target]=(name,payload)
    for target,(name,payload) in destinations.items():
        if target.exists() and target.read_bytes()!=payload:
            saved=backup/safe_relative(name);saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,saved)
            if saved.read_bytes()!=target.read_bytes():raise RuntimeError('Existing-file backup failed')
    for target,(name,payload) in destinations.items():
        target.parent.mkdir(parents=True,exist_ok=True);tmp=None
        try:
            with tempfile.NamedTemporaryFile(dir=target.parent,prefix='.pc-restore-',delete=False) as f:
                tmp=Path(f.name);f.write(payload);f.flush();os.fsync(f.fileno())
            os.replace(tmp,target)
        finally:
            if tmp:tmp.unlink(missing_ok=True)
    print('RESTORE COMPLETE:',program)
    print('Exports:',desktop/'ANAS_DATA_FETCH')
    print('Stores: 13 source entries restored. Template set to the matching discount-tag template.')
    print('Existing different files backed up under:',backup)
    print('Saved-run caches are neither included nor deleted. Automatic fetching is disabled.')
    return destinations

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--desktop',type=Path,default=Path.home()/'Desktop');args=parser.parse_args()
    try:restore(args.desktop)
    except Exception as exc:parser.exit(1,'Restore stopped: '+str(exc)+'\n')
