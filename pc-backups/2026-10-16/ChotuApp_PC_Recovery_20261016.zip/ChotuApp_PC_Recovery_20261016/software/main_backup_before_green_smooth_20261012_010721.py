import tempfile
"""ChotuApp Extractor - Shopify public catalog refresh tool."""
import os, re, json, time, hashlib, threading, queue, html, shutil, csv, datetime
from pathlib import Path
from decimal import Decimal, InvalidOperation
from urllib.parse import urlparse
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import requests

# CHOTUAPP_MANUAL_RESUME_CHECKPOINT_V1
# Persist successful public API responses per store. Replay exact URL on restart;
# never replay failed/partial requests. Clear after a successfully saved Excel.
import sqlite3
import zlib
_chotu_tls = threading.local()
_chotu_pause_gate = threading.Event()
_chotu_pause_gate.set()

class ChotuRateLimited(RuntimeError):
    pass

def _chotu_wait():
    _chotu_pause_gate.wait()

# CHOTUAPP_PAUSE_RATE_LIMIT_RESPONSIVE_V1
def _chotu_backoff(seconds, reason='Retry'):
    deadline = time.monotonic() + max(0, float(seconds))
    while True:
        _chotu_wait()
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return
        if reason == 'Rate limit':
            _chotu_debug('RATE LIMIT: retry in ' + str(int(remaining + .99)) + 's (manual Pause available)')
        time.sleep(min(1.0, remaining))


def _chotu_open_checkpoint(base, name):
    safe = re.sub(r'[^\w .-]', '', name).strip() or 'Shopify'
    identity = hashlib.sha256((base.rstrip('/') + '|' + name).encode()).hexdigest()[:14]
    folder = Path(__file__).resolve().parent / 'resume_checkpoints'
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / (safe + '-' + identity + '.sqlite3')
    db = sqlite3.connect(str(path), timeout=30)
    db.execute('CREATE TABLE IF NOT EXISTS responses (url TEXT PRIMARY KEY, payload BLOB NOT NULL)')
    db.commit()
    _chotu_tls.db = db
    _chotu_tls.checkpoint_path = path
    return path

def _chotu_close_checkpoint(success=False):
    db = getattr(_chotu_tls, 'db', None)
    path = getattr(_chotu_tls, 'checkpoint_path', None)
    _chotu_tls.db = None
    _chotu_tls.checkpoint_path = None
    if db is not None:
        db.close()
    if success and path is not None:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass

# CHOTUAPP_LIVE_DEBUG_V1
import traceback as _chotu_traceback
import urllib.parse as _chotu_urlparse
_chotu_debug_lock = threading.Lock()
_chotu_debug_state = {'stage': 'Idle', 'request': '', 'started': 0.0, 'attempt': 0}
_chotu_debug_sink = None

def _chotu_debug(message):
    global _chotu_debug_sink
    stamp = datetime.datetime.now().strftime('%H:%M:%S')
    line = '[' + stamp + '] ' + str(message)
    sink = _chotu_debug_sink
    if sink is not None:
        try: sink(line)
        except Exception: pass

def _chotu_debug_stage(stage):
    with _chotu_debug_lock:
        _chotu_debug_state['stage'] = stage
    _chotu_debug('STAGE: ' + stage)

def _chotu_debug_request(url, attempt):
    with _chotu_debug_lock:
        _chotu_debug_state.update(request=url, started=time.monotonic(), attempt=attempt)
    _chotu_debug('HTTP START attempt=' + str(attempt) + ' ' + url)

def _chotu_debug_response(status, size=0, cached=False):
    with _chotu_debug_lock:
        started = _chotu_debug_state['started']
        url = _chotu_debug_state['request']
        _chotu_debug_state.update(request='', started=0.0)
    duration = (time.monotonic() - started) if started else 0
    _chotu_debug(('CACHE HIT ' if cached else 'HTTP END ') + 'status=' + str(status) + ' elapsed=' + format(duration, '.1f') + 's bytes=' + str(size) + ' ' + url)

from bs4 import BeautifulSoup
from openpyxl import load_workbook

HOME = Path.home() / 'Desktop'
OUT = HOME / 'ANAS_DATA_FETCH'
CONFIG = HOME / 'chotuapp_extractor_sites.json'
HEADERS = {'User-Agent': 'Mozilla/5.0 (compatible; ChotuAppCatalogRefresh/1.0)'}
S = requests.Session(); S.headers.update(HEADERS)

def get_json(url, tries=3):
    _chotu_debug('GET_JSON: ' + url)
    _chotu_wait()
    db = getattr(_chotu_tls, 'db', None)
    if db is not None:
        cached = db.execute('SELECT payload FROM responses WHERE url=?', (url,)).fetchone()
        if cached is not None:
            _chotu_debug('CACHE HIT: ' + url)
            return json.loads(zlib.decompress(cached[0]).decode('utf-8'))
    for n in range(tries):
        _chotu_wait()
        try:
            _chotu_debug_request(url, n + 1)
            try:
                r = S.get(url, timeout=35)
            except Exception:
                _chotu_debug_response('EXCEPTION')
                raise
            _chotu_debug_response(r.status_code, len(r.content))
            if r.status_code in (403, 404):
                raise RuntimeError(f'Website endpoint unavailable ({r.status_code}): {url}')
            if r.status_code in (429, 503):
                if n == tries - 1:
                    raise ChotuRateLimited(f'HTTP {r.status_code} rate limit at {url}; progress checkpoint saved. Retry later.')
                delay = min(30, 3 * (n + 1))
                retry_after = r.headers.get('Retry-After', '')
                if retry_after.isdigit():
                    delay = min(30, max(delay, int(retry_after)))
                _chotu_debug('RATE LIMIT: HTTP ' + str(r.status_code) + ' waiting ' + str(delay) + 's')
                _chotu_backoff(delay, 'Rate limit')
                continue
            r.raise_for_status()
            data = r.json()
            if db is not None:
                blob = sqlite3.Binary(zlib.compress(json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8'), 5))
                db.execute('INSERT OR REPLACE INTO responses(url,payload) VALUES (?,?)', (url, blob))
                db.commit()
            return data
        except ChotuRateLimited:
            raise
        except (requests.RequestException, ValueError) as exc:
            if n == tries - 1:
                raise RuntimeError(f'Network/JSON error: {exc}') from exc
            _chotu_backoff(n + 1, 'Network retry')
    raise ChotuRateLimited('Rate limit; progress checkpoint saved. Retry later')


def txt(v):
    return re.sub(r'\s+', ' ', html.unescape(BeautifulSoup(str(v or ''), 'html.parser').get_text(' ', strip=True))).strip()

def money(v):
    try: return Decimal(str(v)).quantize(Decimal('0.01'))
    except (InvalidOperation, TypeError, ValueError): return None

def uid(prefix, key): return prefix + hashlib.sha256(str(key).encode()).hexdigest()[:12]

def discover(base, log):
    _chotu_debug_stage('Discover catalog')
    """Collect catalog, then use collection-scoped pagination for large Shopify stores.
    Never silently treat Shopify's 100-page ceiling as catalog completion.
    """
    items = {}; hit_limit = False
    for page in range(1, 101):
        batch = get_json(f'{base}/products.json?limit=250&page={page}').get('products', [])
        for product in batch:
            if product.get('id') is not None:
                items[product['id']] = product
        log(f'  Catalog page {page}: {len(batch)} records')
        if len(batch) < 250:
            return list(items.values()), True
        if getattr(_chotu_tls, 'db', None) is None: time.sleep(.10)
    hit_limit = True
    log('  Shopify 100-page ceiling reached; trying collection-scoped discovery...')
    collections_found = []
    try:
        for page in range(1, 101):
            batch = get_json(f'{base}/collections.json?limit=250&page={page}').get('collections', [])
            collections_found.extend(c for c in batch if c.get('handle'))
            if len(batch) < 250: break
        else:
            log('  WARNING: Collections listing also reached 100-page ceiling')
            return list(items.values()), False
    except ChotuRateLimited as exc:
        # CHOTUAPP_STYLO_429_GRACEFUL_REVIEW_V1
        if (urlparse(base).hostname or '').lower().removeprefix('www.') == 'stylo.pk':
            _chotu_tls.stylo_collections_rate_limited = True
            log('  STYLO RATE LIMITED: collections endpoint blocked; preserving cached products as INCOMPLETE REVIEW, not FINAL.')
            log('  STYLO DETAIL: ' + str(exc))
            return list(items.values()), False
        raise
    except Exception as exc:
        log(f'  WARNING: Could not enumerate collections: {exc}')
        return list(items.values()), False
    complete_collections = True
    added = 0
    for ix, c in enumerate(collections_found, 1):
        handle = c['handle']
        for page in range(1, 101):
            try:
                batch = get_json(f'{base}/collections/{handle}/products.json?limit=250&page={page}').get('products', [])
            except ChotuRateLimited:
                raise
            except Exception as exc:
                complete_collections = False
                log(f'  Collection {handle} failed: {exc}')
                break
            for product in batch:
                pid = product.get('id')
                if pid is not None and pid not in items:
                    items[pid] = product
                    added += 1
            if len(batch) < 250: break
        else:
            complete_collections = False
            log(f'  Collection {handle} reached 100-page ceiling')
        if ix % 20 == 0:
            log(f'  Collections processed: {ix}/{len(collections_found)}; additional products: {added}')
    log(f'  Collection discovery: {len(items)} unique records; {added} beyond initial 25,000')
    # Collection membership cannot guarantee inclusion of uncollected products.
    # Mark as unproven even if every collection paginated successfully.
    return list(items.values()), False

def collections(base, log):
    _chotu_debug_stage('Collection/category mapping')
    mapping={}
    try:
        for page in range(1, 30):
            _chotu_debug('CATEGORY LIST page ' + str(page))
            data=get_json(f'{base}/collections.json?limit=250&page={page}')
            batch=data.get('collections', [])
            if not batch: break
            for c in batch:
                handle=c.get('handle'); title=txt(c.get('title'))
                if not handle or not title: continue
                _chotu_debug('CATEGORY COLLECTION: ' + handle)
                for pageno in range(1, 30):
                    _chotu_wait()
                    try: ps=get_json(f'{base}/collections/{handle}/products.json?limit=250&page={pageno}').get('products',[])
                    except ChotuRateLimited: raise
                    except RuntimeError: break
                    for p in ps: mapping.setdefault(p.get('id'),[]).append(title)
                    if len(ps)<250: break
            if len(batch)<250: break
        log(f'  Collection categories mapped: {len(mapping)} products')
    except ChotuRateLimited: raise
    except RuntimeError as exc: log(f'  Collections incomplete: {exc}')
    return mapping

# CHOTUAPP_FRIENDLY_CATALOG_V1
# Content-only formatting: prices, variants, option names/values, SKU and images are untouched.
# CHOTUAPP_CONSOLIDATED_QUALITY_V1
# Only category and short description presentation; never alters Shopify facts.
# CHOTUAPP_CATEGORY_DESCRIPTION_QUALITY_V2
# Source-grounded categories: clothing never classified by beauty keyword fragments.
def best_category(p, categories):
    title = txt(p.get('title'))
    ptype = txt(p.get('product_type'))
    options = [txt(c) for c in (categories or []) if txt(c)]
    context = ' '.join([title, ptype] + options).lower()
    apparel = re.search(r'\b(dress|gharara|kurta|kurti|shalwar|kameez|khaddar|lawn|cotton suit|embroider|frock|abaya|hijab|shirt|trouser|pants|jeans|dupatta|kids wear|girls wear|boys wear|footwear|shoes|sandal|heels|jacket|hoodie|sweater|co-ord|2 piece|3 piece|two piece|three piece)\b', context)
    beauty = re.search(r'\b(makeup|cosmetic|lipstick|lip gloss|lip liner|lip tint|eyebrow|eyeliner|mascara|eyeshadow|concealer|foundation|primer|blush|highlighter|contour|bronzer|nail polish|face powder|lip balm|perfume|fragrance|skincare)\b', context)
    generic = re.compile(r'(?i)^(all|all products|shop all|shop all products|in stock feed|new arrivals?|best sellers?|sale|deals?|offers?|featured|uncategorized|general|catalog|products?|collections?|shop now)$')
    def useful(value):
        value = txt(value)
        return bool(value) and not generic.fullmatch(value) and not re.search(r'(?i)\b(sale|discount|clearance|new arrival|best seller|trending|shop now|feed|under rs|under pkr)\b', value)
    # Explicit apparel context takes precedence over ambiguous substrings like 'brow' in 'brown'.
    if apparel:
        apparel_types = [c for c in [ptype] + options if useful(c) and re.search(r'(?i)\b(dress|gharara|kurta|kurti|suit|frock|abaya|hijab|shirt|trouser|pants|jeans|dupatta|girls|boys|kids|footwear|shoes|sandal|heels|jacket|hoodie|sweater|clothing|apparel|co-ord)\b', c)]
        if apparel_types:
            return min(apparel_types, key=lambda x: (len(x), x.lower()))
        if re.search(r'(?i)\b(shoes|sandal|heels|footwear)\b', title): return 'Footwear'
        if re.search(r'(?i)\b(dress|gharara|frock)\b', title): return 'Dresses'
        return 'Clothing'
    patterns = [(r'\blip\s*liner\b|\blipliner\b','Lip Liner'),(r'\blip\s*gloss\b|\blip\s*oil\b','Lip Gloss'),(r'\blip\s*tint\b','Lip Tint'),(r'\blipstick\b|\blip\s*cream\b','Lipstick'),(r'\beyebrow\b|\bbrow\s*(?:pencil|gel|powder|kit)\b','Eyebrow Makeup'),(r'\beyeliner\b|\bkajal\b','Eyeliner & Kajal'),(r'\bmascara\b','Mascara'),(r'\beyeshadow\b|\beye shadow\b','Eyeshadow'),(r'\bconcealer\b','Concealer'),(r'\bfoundation\b|\bbb cream\b','Foundation'),(r'\bprimer\b','Primer'),(r'\bblush\b','Blush'),(r'\bhighlighter\b','Highlighter'),(r'\bcontour\b|\bbronzer\b','Contour & Bronzer'),(r'\bface powder\b|\bsetting powder\b|\bloose powder\b','Face Powder'),(r'\bmakeup brush\b|\bmakeup sponge\b|\bmakeup puff\b','Makeup Tools'),(r'\bperfume\b|\bfragrance\b','Fragrances'),(r'\bnail polish\b|\bnail paint\b','Nail Makeup'),(r'\blip balm\b|\blip mask\b','Lip Care'),(r'\bmakeup kit\b|\bmakeup set\b','Makeup Sets')]
    if beauty:
        for pattern, category in patterns:
            if re.search(pattern, title, re.I): return category
    if useful(ptype): return ptype
    valid = [c for c in options if useful(c)]
    if valid: return min(valid, key=lambda x: (len(x), x.lower()))
    return 'Uncategorized'

# Medium-length description: prefer original source wording; no invented features.
def friendly_description(p):
    title = txt(p.get('title'))
    body = p.get('body_html') or ''
    if not body: return title
    soup = BeautifulSoup(str(body), 'html.parser')
    for tag in soup.find_all(['script', 'style', 'noscript', 'iframe', 'svg']): tag.decompose()
    for tag in soup.find_all(['p', 'li', 'h2', 'h3', 'h4', 'br', 'div']): tag.insert_before('\n')
    source = html.unescape(soup.get_text(' ', strip=False)).replace('\xa0', ' ')
    reject = re.compile(r'(?i)(add to cart|buy now|shop now|wishlist|share this|free shipping|cash on delivery|return policy|subscribe|newsletter|follow us|limited time|hurry|order now|click here|discount code|customer reviews|read more|view all|related products|you may also like)')
    candidates, seen = [], set()
    for line in source.splitlines():
        line = re.sub(r'\s+', ' ', line).strip(' •|:-\t')
        if not line or reject.search(line): continue
        for sentence in re.split(r'(?<=[.!?])\s+(?=[A-Z0-9])', line):
            sentence = sentence.strip(' •|:-\t')
            if len(sentence) < 15 or len(sentence) > 400 or 'http' in sentence.lower(): continue
            key = re.sub(r'\W+', '', sentence).casefold()
            if key and key not in seen:
                seen.add(key); candidates.append(sentence)
    if not candidates: return title
    title_words = set(re.findall(r'[a-z0-9]{4,}', title.lower()))
    def rank(sentence):
        lower = sentence.lower()
        return (sum(w in lower for w in title_words) * 3 + len(re.findall(r'\b(size|shade|color|colour|material|fabric|includes|contains|made|capacity|volume|weight|finish|texture|set|pack|piece|ml|cm)\b', lower)) * 2)
    ranked = sorted(enumerate(candidates), key=lambda item: (-rank(item[1]), item[0]))
    chosen, length = set(), 0
    for i, sentence in ranked:
        extra = len(sentence) + (1 if chosen else 0)
        if length + extra > 400: continue
        chosen.add(i); length += extra
        if length >= 250 or len(chosen) >= 4: break
    result = ' '.join(s for i, s in enumerate(candidates) if i in chosen)
    return result or title

# CHOTUAPP_PRICE_AUDIT_V1
# Read-only cross-endpoint verification. Does not change prices or variants.
def audit_fractional_prices(base, rows, combos, output, log):
    from urllib.parse import urlparse
    by_product = {}
    for c in combos:
        by_product.setdefault(c.get('product_id'), []).append(c)
    findings = []
    checked = 0
    for r in rows:
        _chotu_wait()
        bp = money(r.get('base_price (PKR)'))
        sp = money(r.get('sale_price (PKR, agar discount ho)'))
        if not any(v is not None and v != v.to_integral_value() for v in (bp, sp)):
            continue
        checked += 1
        url = r.get('source_url') or ''
        try:
            handle = urlparse(url).path.rstrip('/').split('/')[-1]
            live = get_json(f"{base}/products/{handle}.js")
            live_variants = {str(v.get('id')): v for v in live.get('variants', [])}
            if not live_variants:
                findings.append(('REVIEW', url, '', 'NO_LIVE_VARIANTS', '', '', 'Product .js endpoint returned no variants'))
                continue
            for c in by_product.get(r['product_id'], []):
                vid = str(c.get('source_variant_id') or '')
                current = live_variants.get(vid)
                if current is None:
                    findings.append(('REVIEW', url, vid, 'VARIANT_MISSING', '', '', 'Variant absent from current product.js'))
                    continue
                # Shopify product.js amounts are integer minor currency units (cents/paisa).
                try:
                    live_price = (Decimal(str(current['price'])) / Decimal('100')).quantize(Decimal('0.01'))
                    live_compare = (Decimal(str(current['compare_at_price'])) / Decimal('100')).quantize(Decimal('0.01')) if current.get('compare_at_price') is not None else None
                except (InvalidOperation, TypeError, ValueError, KeyError) as exc:
                    findings.append(('REVIEW', url, vid, 'UNREADABLE_LIVE_PRICE', '', '', str(exc)))
                    continue
                expected_base = live_compare if live_compare is not None and live_compare > live_price else live_price
                expected_sale = live_price if expected_base > live_price else None
                exported_base = money(c.get('base_price (PKR)'))
                exported_sale = money(c.get('sale_price (PKR, agar discount ho)'))
                if exported_base != expected_base or exported_sale != expected_sale:
                    findings.append(('MISMATCH', url, vid, 'VARIANT_PRICE_DIFFERENCE', f'{exported_base} / {exported_sale}', f'{expected_base} / {expected_sale}', 'Export base/sale vs current product.js base/sale'))
            if not any(x[1] == url for x in findings):
                findings.append(('CHECKED', url, '', 'API_PRICES_MATCH', '', '', 'Current product.js variants agree; storefront display and checkout NOT verified'))
        except Exception as exc:
            findings.append(('REVIEW', url, '', 'FETCH_FAILED', '', '', str(exc)))
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('w', encoding='utf-8-sig', newline='') as f:
        w=csv.writer(f)
        w.writerow(['status','product_url','source_variant_id','check','export_base_sale','current_api_base_sale','detail'])
        w.writerows(findings)
    problems=sum(x[0] in ('REVIEW','MISMATCH') for x in findings)
    log(f'PRICE AUDIT: {output} ({checked} fractional-price products checked; {problems} review/mismatch rows)')
    log('PRICE AUDIT NOTE: product.js is a second Shopify API endpoint, NOT visual storefront/checkout verification. No prices changed.')

# CHOTUAPP_STOREFRONT_AUDIT_V1
# Website's static price markup is not guaranteed to equal JS-rendered/cart/checkout price.
# CHOTUAPP_RATE_LIMIT_SAFETY_V2
def storefront_price_audit(rows, output, log):
    # HTTP 429 is an incomplete verification, never a confirmed price mismatch.
    import email.utils
    import random
    from decimal import Decimal as _Decimal
    from bs4 import BeautifulSoup as _Soup
    findings = []
    checked = 0
    session = requests.Session()
    session.headers.update({'User-Agent': 'Mozilla/5.0 (compatible; ChotuAppCatalogRefresh/1.0)'})
    for r in rows:
        _chotu_wait()
        base = money(r.get('base_price (PKR)'))
        sale = money(r.get('sale_price (PKR, agar discount ho)'))
        if not any(x is not None and x != x.to_integral_value() for x in (base, sale)):
            continue
        checked += 1
        url = r.get('source_url') or ''
        try:
            resp = None
            for attempt in range(2):  # One initial request and at most one retry.
                resp = session.get(url, timeout=25)
                if resp.status_code not in (429, 503):
                    break
                if attempt == 0:
                    retry_header = resp.headers.get('Retry-After', '')
                    delay = 8.0
                    if retry_header:
                        try:
                            delay = float(retry_header)
                        except ValueError:
                            try:
                                dt = email.utils.parsedate_to_datetime(retry_header)
                                delay = (dt - datetime.datetime.now(datetime.timezone.utc)).total_seconds()
                            except (TypeError, ValueError, OverflowError):
                                pass
                    if delay > 30:
                        log('  Server requested a long retry delay; deferring verification instead.')
                        break
                    delay = max(3.0, delay)
                    log(f'  HTTP {resp.status_code} for {url}; waiting {delay:.0f}s before one retry')
                    time.sleep(delay)
            if resp.status_code in (429, 503):
                findings.append(['RATE_LIMITED', url, str(resp.status_code), str(base), str(sale), '',
                                 'Storefront verification deferred; API price unchanged; NOT a mismatch'])
                log(f'  RATE LIMITED: {url} (HTTP {resp.status_code}); verification pending')
                # Avoid further page requests when the site is throttling.
                break
            if resp.status_code != 200:
                findings.append(['REVIEW', url, str(resp.status_code), str(base), str(sale), '',
                                 'HTTP status not 200; verification pending'])
                continue
            soup = _Soup(resp.text, 'html.parser')
            nodes = soup.select('.price-item--sale, .price-item--regular, .price-item')
            values = []
            for node in nodes[:16]:
                match = re.search(r'(?:Rs\.?|PKR\s*)([\d,]+(?:\.\d+)?)',
                                  node.get_text(' ', strip=True), re.I)
                if match:
                    value = _Decimal(match.group(1).replace(',', ''))
                    if value not in values:
                        values.append(value)
            if not values:
                findings.append(['REVIEW', url, '200', str(base), str(sale), '',
                                 'No recognizable theme price; do not infer'])
                continue
            active = sale if sale is not None else base
            display = active.quantize(_Decimal('1')) if active is not None else None
            if active in values:
                status = 'EXACT_DISPLAY_MATCH'
            elif display in values:
                status = 'DISPLAY_WHOLE_RUPEE_MATCH'
            else:
                status = 'REVIEW'
            findings.append([status, url, '200', str(base), str(sale),
                             ' / '.join(map(str, values)),
                             'Static HTML only; checkout and JS changes not verified'])
            time.sleep(0.5)
        except requests.RequestException as exc:
            findings.append(['REVIEW', url, '', str(base), str(sale), '',
                             'Network failure: ' + str(exc)[:140]])
        except Exception as exc:
            findings.append(['REVIEW', url, '', str(base), str(sale), '', str(exc)[:180]])
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['status', 'product_url', 'http_status', 'api_base',
                    'api_sale', 'html_price_values', 'note'])
        w.writerows(findings)
    reviews = sum(x[0] in ('REVIEW', 'RATE_LIMITED') for x in findings)
    log(f'STOREFRONT AUDIT: {output} ({checked} fractional-price products; '
        f'{reviews} pending/review; {sum(x[0] == "RATE_LIMITED" for x in findings)} rate limited)')
    log('STOREFRONT NOTE: HTML is not checkout; no source or exported prices changed.')
    return {x[1] for x in findings
            if x[0] in ('EXACT_DISPLAY_MATCH', 'DISPLAY_WHOLE_RUPEE_MATCH')}

def write_row(ws, vals):
    cols={str(c.value).strip():c.column for c in ws[1] if c.value is not None}
    ws.append([vals.get(str(ws.cell(1,j).value).strip()) for j in range(1,ws.max_column+1)])

def run_site(base, name, template, log):
    # CHOTUAPP_MULTIDIM_VARIANTS_V1
    OUT.mkdir(exist_ok=True)
    _chotu_tls.stylo_collections_rate_limited = False
    products, complete_catalog=discover(base,log)
    if not products: raise RuntimeError('No public products found. Shopify endpoint may be unavailable.')
    if getattr(_chotu_tls, 'stylo_collections_rate_limited', False):
        log('  STYLO: Skipping category endpoint after HTTP 429; using product type/title fallback. Category accuracy needs REVIEW.')
        cats = {}
    else:
        cats=collections(base,log)
    _chotu_debug_stage('Building Excel rows')
    wb=load_workbook(template)
    for sheet in ('Products','Product Images','Option Groups','Options','Variant Combinations'):
        if sheet not in wb.sheetnames: raise RuntimeError(f'Template missing sheet: {sheet}')
        ws=wb[sheet]
        if ws.max_row>1: ws.delete_rows(2,ws.max_row-1)
    rows=[]; imgs=[]; groups=[]; opts=[]; combos=[]; review=[]
    skipped_hidden = skipped_out_of_stock = skipped_invalid = 0
    for p in products:
        _chotu_wait()
        variants=[v for v in p.get('variants',[]) if v.get('id') is not None]
        priced=[v for v in variants if money(v.get('price')) is not None and money(v.get('price'))>0]
        # CHOTUAPP_AVAILABLE_PRODUCTS_ONLY_V1
        # A public catalog listing is not proof that a product is visible in every channel.
        # If Shopify explicitly reports unpublished/draft/archived, exclude it.
        status = str(p.get('status') or '').strip().lower()
        if status and status != 'active':
            skipped_hidden += 1
            continue
        if 'published_at' in p and not p.get('published_at'):
            skipped_hidden += 1
            continue
        if not p.get('handle') or not priced:
            skipped_invalid += 1
            continue
        available_priced=[v for v in priced if v.get('available') is True]
        # Skip entirely unavailable products, but keep ALL variants of available products.
        if not available_priced:
            skipped_out_of_stock += 1
            continue
        cheapest=min(available_priced or priced,key=lambda v:money(v['price']))
        lowest=money(cheapest['price'])
        compare=money(cheapest.get('compare_at_price'))
        baseprice=compare if compare is not None and compare>lowest else lowest
        sale=lowest if baseprice>lowest else None
        pid=uid('CP',base+'|'+str(p['id']))
        pictures=[im for im in (p.get('images') or []) if isinstance(im,dict) and im.get('src')]
        pictures.sort(key=lambda im:(im.get('position') if isinstance(im.get('position'),int) else 999999))
        featured=(p.get('image') or {}).get('src') or ''
        if featured:
            pictures.sort(key=lambda im:0 if im.get('src')==featured else 1)
        seen_urls=set(); pictures=[im for im in pictures if not (im['src'] in seen_urls or seen_urls.add(im['src']))]
        cover=pictures[0]['src'] if pictures else featured
        category=best_category(p,cats.get(p.get('id'),[]))
        desc=friendly_description(p)
        url=f"{base}/products/{p['handle']}"
        dimensions=[]
        for idx,dim in enumerate((p.get('options') or [])[:3],1):
            title=txt(dim.get('name')) or f'Option {idx}'
            values=[]
            for v in variants:
                value=txt(v.get(f'option{idx}'))
                if value and value not in values: values.append(value)
            if values and not (len(values)==1 and values[0].lower() in ('default title','default')):
                # CHOTUAPP_VERIFIED_SHADE_QUALITY_V1: exact observed Shopify product only.
                if (urlparse(base).hostname or '').lower().removeprefix('www.') == 'missrose.com.pk' and p.get('handle') == 'miss-rose-under-eye-pencil-2' and idx == 1 and title.casefold() == 'title' and set(values) == {'White M3', 'nude M1'}:
                    title = 'Shade'
                gid=uid('CG',pid+'|'+str(idx))
                dimensions.append((idx,gid,title,values))
                groups.append({'group_id':gid,'title (customer ko dikhega)':title,'select_type':'single','min':1,'max':1,'required (yes/no)':'yes'})
                for value in values:
                    matching=[v for v in variants if txt(v.get(f'option{idx}'))==value]
                    # Option yes means at least one actual combination containing it is available.
                    opts.append({'option_id':uid('CO',gid+'|'+value),'group_id':gid,'option_name':value,'extra_price (PKR)':0,'option_image_url (agar size/color/variant ki apni image ho)':'','available (yes/no)':'yes' if any(v.get('available') is True for v in matching) else 'no'})
        gid=','.join(x[1] for x in dimensions)
        for v in variants:
            vp=money(v.get('price')); vc=money(v.get('compare_at_price'))
            variant_base=vc if vp is not None and vc is not None and vc>vp else vp
            variant_sale=vp if vp is not None and variant_base is not None and variant_base>vp else None
            image=v.get('featured_image') or {}
            image_url=image.get('src') if isinstance(image,dict) else ''
            entry={'combination_id':uid('CC',base+'|'+str(v['id'])),'product_id':pid,'source_variant_id':str(v['id']),'sku':str(v.get('sku') or ''),'base_price (PKR)':float(variant_base) if variant_base is not None else None,'sale_price (PKR, agar discount ho)':float(variant_sale) if variant_sale is not None else None,'available (yes/no)':'yes' if v.get('available') is True else 'no','stock_quantity (agar public ho)':'','variant_image_url':image_url or '','source_url':url}
            for pos,(idx,group_id,title,values) in enumerate(dimensions,1):
                entry[f'option_{pos}_group_id']=group_id
                entry[f'option_{pos}_value']=txt(v.get(f'option{idx}'))
            combos.append(entry)
        if len(p.get('options') or [])>3: review.append(f'More than 3 dimensions: {url}')
        rows.append({'product_id':pid,'category':category,'subcategory':'','name':txt(p.get('title')),'description':desc,'brand':txt(p.get('vendor')) or name,'material':'','weight_grams (agar ho)':'','condition (new/used)':'new','warranty_months (agar ho)':'','base_price (PKR)':float(baseprice),'sale_price (PKR, agar discount ho)':float(sale) if sale is not None else None,'sku':str(cheapest.get('sku') or ''),'scraped_image_url (cover, auto)':cover,'final_image_url (cover/thumbnail — hosted link)':'','option_groups':gid,'available (yes/no)':'yes' if any(v.get('available') is True for v in variants) else 'no','stock_quantity (kitni quantity bechni hai)':'','max_qty_per_user (ek user zyada se zyada kitni le sakta hai)':'','source_url':url})
        if not pictures: review.append(f'No image: {p.get("title")}')
        for i,im in enumerate(pictures,1):
            src=im.get('src')
            if not src: continue
            imgs.append({'image_id':uid('CI',pid+'|'+str(im.get('id') or i)),'product_id':pid,'image_order':i,'scraped_image_url (auto)':src,'final_image_url (paste — hosted link)':'','is_primary (yes/no)':'yes' if i==1 else 'no','source_url':url})
    log(f'PRODUCT FILTER: skipped {skipped_out_of_stock} fully unavailable, {skipped_hidden} explicitly unpublished, {skipped_invalid} invalid/unpriced; retained {len(rows)} available products with ALL their variants')
    if not rows: raise RuntimeError('No available, priced products found')
    rows.sort(key=lambda x:(x['category'].lower(), x['sale_price (PKR, agar discount ho)'] or x['base_price (PKR)'],x['name'].lower()))
    for r in rows: write_row(wb['Products'],r)
    for r in imgs: write_row(wb['Product Images'],r)
    for r in groups: write_row(wb['Option Groups'],r)
    for r in opts: write_row(wb['Options'],r)
    for r in combos: write_row(wb['Variant Combinations'],r)
    if len({x['combination_id'] for x in combos})!=len(combos): raise RuntimeError('Duplicate combination IDs')
    if any(x['product_id'] not in {r['product_id'] for r in rows} for x in combos): raise RuntimeError('Orphan variant combination')
    if len({r['product_id'] for r in rows})!=len(rows): raise RuntimeError('Duplicate product IDs')
    if any(x['product_id'] not in {r['product_id'] for r in rows} for x in imgs): raise RuntimeError('Orphan image')
    safe=re.sub(r'[^\w .-]','',name).strip() or 'Shopify'
    target=OUT/f'{safe} - REFRESH REVIEW.xlsx'; temp=OUT/f'{safe} - BUILDING.xlsx'
    _chotu_debug_stage('Saving Excel workbook')
    wb.save(temp)
    verify=load_workbook(temp,read_only=True)
    if verify['Products'].max_row-1!=len(rows): raise RuntimeError('Export row count mismatch')
    verify.close()
    os.replace(temp,target)
    log(f'EXPORT BUILT: {len(rows)} products, {len(imgs)} images, {len(groups)} selector groups, {len(opts)} selector values, {len(combos)} actual variants ({sum(x["available (yes/no)"]=="no" for x in combos)} unavailable)')
    log(f'FILE: {target}')
    audit_fractional_prices(base, rows, combos, OUT/f'{safe} - PRICE AUDIT.csv', log)
    storefront_verified = storefront_price_audit(rows, OUT/f'{safe} - STOREFRONT AUDIT.csv', log)
    quality_issues = quality_validation(rows, imgs, groups, opts, combos, OUT/f'{safe} - QUALITY REPORT.csv', log, storefront_verified)
    final=OUT/f'{safe} - FINAL.xlsx'
    report=OUT/f'{safe} - CHANGE REPORT.csv'
    old_rows={}
    if final.is_file():
        old_wb=load_workbook(final,read_only=True,data_only=True)
        old_ws=old_wb['Products']
        old_iter=old_ws.values
        old_headers=list(next(old_iter))
        for values in old_iter:
            d=dict(zip(old_headers,values))
            if d.get('source_url'): old_rows[d['source_url']]=d
        old_wb.close()
    new_rows={r['source_url']:r for r in rows}
    changes=[]
    price_keys=('base_price (PKR)','sale_price (PKR, agar discount ho)')
    for url,r in new_rows.items():
        if url not in old_rows:
            changes.append(('ADDED',url,'',''))
        else:
            old=old_rows[url]
            for key in price_keys:
                if money(old.get(key)) != money(r.get(key)):
                    changes.append(('PRICE CHANGE',url,key,f'{old.get(key)} -> {r.get(key)}'))
    for url in old_rows.keys()-new_rows.keys():
        changes.append(('MISSING IN REFRESH',url,'','Check stock / page visibility'))
    with report.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['change','product_url','field','detail']);w.writerows(changes)
    log(f'CHANGE REPORT: {report} ({len(changes)} changes)')
    if final.exists():
        log(f'OLD vs NEW: {len(old_rows)} -> {len(new_rows)} products')
    if quality_issues:
        log('STATUS: REVIEW REQUIRED — quality report has findings')
    elif not complete_catalog:
        log('STATUS: REVIEW REQUIRED — large catalog completeness unverified')
    elif any(',' in r['option_groups'] for r in rows):
        log('STATUS: REVIEW REQUIRED — multi-selector importer and combination mapping must be confirmed by developer')
    elif review:
        log('STATUS: REVIEW REQUIRED — missing product images')
    else:
        log('STATUS: REVIEW READY — product-page verification and ChotuApp import not guaranteed')

    log('Existing FINAL file preserved. Review refresh before manually replacing it.')
    if not complete_catalog: log('WARNING: Catalog completeness NOT PROVEN (Shopify 100-page ceiling). Never auto-promote this export.')
    if review: log(f'REVIEW: {len(review)} products without gallery images')
    log('NOTE: Public catalog only; not a checkout, importer or current product-page verification.')


def quality_validation(rows, imgs, groups, opts, combos, output, log, storefront_verified=None):
    storefront_verified = storefront_verified or set()
    # CHOTUAPP_QUALITY_VALIDATION_V1
    # Read-only checks: do not alter source data or auto-correct prices/categories.
    from collections import Counter, defaultdict
    issues = []
    product_ids = {r['product_id'] for r in rows}
    group_ids = {g['group_id'] for g in groups}
    option_values = defaultdict(set)
    for o in opts:
        option_values[o.get('group_id')].add(str(o.get('option_name') or ''))
    group_owner = {}
    for r in rows:
        for gid in str(r.get('option_groups') or '').split(','):
            if gid:
                group_owner[gid] = r['product_id']
    product_urls = {r['product_id']: r.get('source_url', '') for r in rows}

    def flag(severity, code, pid='', detail='', url=''):
        issues.append((severity, code, str(pid or ''), str(url or product_urls.get(pid, '')), str(detail)))

    generic = {'miss rose product categories', 'in stock feed', 'all products',
               'shop all', 'sale', 'new arrivals', 'uncategorized', 'general'}
    product_id_counts = Counter(r.get('product_id') for r in rows)
    url_counts = Counter(r.get('source_url') for r in rows)
    images_by_pid = defaultdict(list)
    image_keys = Counter()
    for im in imgs:
        pid = im.get('product_id')
        images_by_pid[pid].append(im)
        image_keys[(pid, im.get('scraped_image_url (auto)'))] += 1
        if pid not in product_ids:
            flag('ERROR', 'ORPHAN_IMAGE', pid, 'Image refers to absent product', im.get('source_url'))
    for (pid, src), count in image_keys.items():
        if count > 1:
            flag('WARNING', 'DUPLICATE_IMAGE_URL', pid, f'{count} copies: {src}')

    for r in rows:
        pid = r['product_id']
        url = r.get('source_url', '')
        if product_id_counts[pid] > 1:
            flag('ERROR', 'DUPLICATE_PRODUCT_ID', pid, product_id_counts[pid], url)
        if url_counts[url] > 1:
            flag('ERROR', 'DUPLICATE_PRODUCT_URL', pid, url_counts[url], url)
        cat = str(r.get('category') or '').strip()
        if not cat or cat.casefold() in generic or 'categories' in cat.casefold() or 'feed' in cat.casefold():
            flag('WARNING', 'GENERIC_CATEGORY', pid, cat or '(empty)', url)
        desc = str(r.get('description') or '').strip()
        if len(desc) > 300:
            flag('WARNING', 'LONG_APP_DESCRIPTION', pid, f'{len(desc)} characters', url)
        if re.search(r'(?i)\b(free gift|premium orders|free for orders)\b',str(r.get('name') or '')):
            flag('WARNING', 'PROMOTIONAL_PRODUCT_REVIEW', pid, 'Confirm this is separately saleable before importing', url)
        if not desc:
            flag('ERROR', 'MISSING_DESCRIPTION', pid, '', url)
        elif len(desc) < 35 or desc.casefold() == str(r.get('name') or '').strip().casefold():
            flag('WARNING', 'SHORT_DESCRIPTION', pid, f'{len(desc)} characters', url)
        cover = str(r.get('scraped_image_url (cover, auto)') or '').strip()
        if not cover:
            flag('ERROR', 'MISSING_COVER', pid, '', url)
        elif not (cover.startswith('https://') or cover.startswith('http://') or cover.startswith('//')):
            flag('WARNING', 'INVALID_COVER_URL', pid, cover, url)
        if not images_by_pid[pid]:
            flag('ERROR', 'MISSING_GALLERY', pid, '', url)
        base = money(r.get('base_price (PKR)'))
        sale = money(r.get('sale_price (PKR, agar discount ho)'))
        if base is None or base <= 0:
            flag('ERROR', 'INVALID_BASE_PRICE', pid, str(base), url)
        if sale is not None and (sale <= 0 or (base is not None and sale >= base)):
            flag('WARNING', 'SUSPICIOUS_SALE_PRICE', pid, f'base={base}, sale={sale}', url)
        if any(p is not None and p != p.to_integral_value() for p in (base, sale)):
            if url in storefront_verified:
                flag('INFO', 'FRACTIONAL_PRICE_DISPLAY_MATCH', pid, f'API base={base}, sale={sale}; static storefront HTML matched exact/whole-rupee active price; no export change', url)
            else:
                flag('WARNING', 'FRACTIONAL_PKR_PRICE', pid, f'base={base}, sale={sale}', url)
        for gid in str(r.get('option_groups') or '').split(','):
            if gid and gid not in group_ids:
                flag('ERROR', 'MISSING_OPTION_GROUP', pid, gid, url)

    for g in groups:
        gid = g['group_id']
        pid = group_owner.get(gid, '')
        if not pid:
            flag('ERROR', 'UNREFERENCED_GROUP', '', gid)
        title = str(g.get('title (customer ko dikhega)') or '').strip()
        if title.casefold() in ('title', 'default title', 'default', 'option'):
            flag('WARNING', 'PLACEHOLDER_GROUP_TITLE', pid, title)
        if not option_values.get(gid):
            flag('ERROR', 'EMPTY_OPTION_GROUP', pid, gid)
    for o in opts:
        gid = o.get('group_id')
        if gid not in group_ids:
            flag('ERROR', 'ORPHAN_OPTION', '', str(gid))
        if o.get('available (yes/no)') not in ('yes', 'no'):
            flag('ERROR', 'INVALID_OPTION_AVAILABILITY', group_owner.get(gid, ''), str(o.get('available (yes/no)')))

    variant_ids = Counter((c.get('product_id'), str(c.get('source_variant_id'))) for c in combos)
    combos_by_pid = defaultdict(list)
    for c in combos:
        pid = c.get('product_id')
        combos_by_pid[pid].append(c)
        if pid not in product_ids:
            flag('ERROR', 'ORPHAN_COMBINATION', pid, c.get('source_variant_id'), c.get('source_url'))
        if variant_ids[(pid, str(c.get('source_variant_id')))] > 1:
            flag('ERROR', 'DUPLICATE_VARIANT_ID', pid, c.get('source_variant_id'))
        if c.get('available (yes/no)') not in ('yes', 'no'):
            flag('ERROR', 'INVALID_VARIANT_AVAILABILITY', pid, c.get('source_variant_id'))
        base = money(c.get('base_price (PKR)'))
        sale = money(c.get('sale_price (PKR, agar discount ho)'))
        if base is None or base <= 0:
            flag('WARNING', 'VARIANT_MISSING_PRICE', pid, c.get('source_variant_id'))
        if sale is not None and (sale <= 0 or (base is not None and sale >= base)):
            flag('WARNING', 'VARIANT_SALE_PRICE', pid, c.get('source_variant_id'))
        for i in (1, 2, 3):
            gid = c.get(f'option_{i}_group_id')
            value = c.get(f'option_{i}_value')
            if gid and gid not in group_ids:
                flag('ERROR', 'VARIANT_UNKNOWN_GROUP', pid, f'{gid}: {value}')
            elif gid and str(value or '') not in option_values.get(gid, set()):
                flag('ERROR', 'VARIANT_UNKNOWN_VALUE', pid, f'{gid}: {value}')
            if gid and group_owner.get(gid) != pid:
                flag('ERROR', 'VARIANT_WRONG_PRODUCT_GROUP', pid, gid)

    for r in rows:
        pid = r['product_id']
        cs = combos_by_pid.get(pid, [])
        if not cs:
            flag('ERROR', 'PRODUCT_WITHOUT_VARIANTS', pid)
        else:
            actual = 'yes' if any(c.get('available (yes/no)') == 'yes' for c in cs) else 'no'
            if r.get('available (yes/no)') != actual:
                flag('ERROR', 'PRODUCT_AVAILABILITY_MISMATCH', pid, f'product={r.get("available (yes/no)")}, variants={actual}')

    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['severity', 'issue_code', 'product_id', 'source_url', 'detail'])
        w.writerows(issues)
    counts = Counter(x[0] for x in issues)
    log(f'QUALITY REPORT: {output} ({len(issues)} findings; {counts["ERROR"]} errors, {counts["WARNING"]} warnings)')
    log('QUALITY NOTE: Structural and heuristic checks only; live website price, images, and checkout NOT verified.')
    return sum(x[0] in ('ERROR', 'WARNING') for x in issues)



# CHOTUAPP_PROGRESS_SINGLE_FINAL_V1
# Percentage represents pipeline stages, not exact network bytes or elapsed time.
_chotuapp_run_site_original = run_site

def run_site(base, name, template, log):
    global OUT
    real_out = OUT
    safe = re.sub(r'[^\w .-]', '', name).strip() or 'Shopify'
    software_dir = Path(__file__).resolve().parent
    audit_dir = software_dir / 'audit_reports' / safe
    staging_root = software_dir / '_build_temp'
    staging_root.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix='chotu_', dir=str(staging_root)))
    final = real_out / (safe + ' - FINAL.xlsx')
    current_progress = 0

    def progress(pct, message):
        nonlocal current_progress
        pct = max(current_progress, min(100, int(pct)))
        current_progress = pct
        log('__CHOTU_PROGRESS__|' + str(pct) + '|' + str(message))

    def intercept(message):
        text = str(message)
        log(text)
        if 'Catalog page ' in text:
            progress(min(25, 5 + 2 * len([x for x in logs if 'Catalog page ' in x])), 'Fetching catalog')
        elif 'Collection categories mapped:' in text:
            progress(35, 'Categories mapped')
        elif 'PRODUCT FILTER:' in text:
            progress(58, 'Products and variants processed')
        elif 'EXPORT BUILT:' in text:
            progress(70, 'Excel built')
        elif 'PRICE AUDIT:' in text:
            progress(80, 'Price audit complete')
        elif 'STOREFRONT AUDIT:' in text:
            progress(88, 'Storefront audit complete')
        elif 'QUALITY REPORT:' in text:
            progress(93, 'Quality checks complete')
        elif 'CHANGE REPORT:' in text:
            progress(96, 'Change report complete')
        logs.append(text)

    logs = []
    progress(1, 'Starting ' + name)
    try:
        real_out.mkdir(parents=True, exist_ok=True)
        # Keep original FINAL available for old-vs-new comparison inside the staging area.
        if final.exists():
            shutil.copy2(final, staging / final.name)
        OUT = staging
        try:
            _chotuapp_run_site_original(base, name, template, intercept)
        finally:
            OUT = real_out

        review_file = staging / (safe + ' - REFRESH REVIEW.xlsx')
        if not review_file.is_file():
            raise RuntimeError('Refresh workbook missing; existing FINAL preserved')

        # CHOTUAPP_DECIMAL_TRUNCATE_V1
        # User-selected integer PKR export policy. Original source prices remain in API audit.
        # Do not silently publish transformed prices as verified FINAL.
        from decimal import Decimal as _Decimal
        _book = load_workbook(review_file)
        _changed = 0
        for _sheet_name in ('Products', 'Variant Combinations'):
            if _sheet_name not in _book.sheetnames:
                _book.close()
                raise RuntimeError('Price policy: missing sheet ' + _sheet_name)
            _ws = _book[_sheet_name]
            _headers = {str(c.value).strip(): c.column for c in _ws[1] if c.value is not None}
            for _field in ('base_price (PKR)', 'sale_price (PKR, agar discount ho)'):
                if _field not in _headers:
                    _book.close()
                    raise RuntimeError('Price policy: missing column ' + _field)
                for _cells in _ws.iter_rows(min_row=2, min_col=_headers[_field], max_col=_headers[_field]):
                    _cell = _cells[0]
                    if _cell.value is None or _cell.value == '':
                        continue
                    try:
                        _value = _Decimal(str(_cell.value))
                        if not _value.is_finite() or _value < 0:
                            raise ValueError('Invalid price')
                        _integer = int(_value)  # truncate, do not round
                    except Exception as _exc:
                        _book.close()
                        raise RuntimeError('Price policy: invalid value in ' + _sheet_name + ' cell ' + _cell.coordinate) from _exc
                    if _value != _integer:
                        _cell.value = _integer
                        _changed += 1
        if _changed:
            _temp = staging / (safe + ' - PRICE POLICY BUILDING.xlsx')
            try:
                _book.save(_temp)
                _book.close()
                _check = load_workbook(_temp, read_only=True)
                _check.close()
                os.replace(_temp, review_file)
            finally:
                _book.close()
                if _temp.exists(): _temp.unlink()
        else:
            _book.close()
        log('PRICE POLICY: Removed fractional parts from ' + str(_changed) + ' Excel price cells (Products + Variant Combinations); original API price audits preserved.')

        def problem_rows(filename, bad_values, column):
            file = staging / (safe + ' - ' + filename + '.csv')
            if not file.exists():
                return [filename + ' report missing']
            with file.open('r', encoding='utf-8-sig', newline='') as stream:
                reader = csv.DictReader(stream)
                if not reader.fieldnames or column not in reader.fieldnames:
                    return [filename + ' report malformed']
                return [str(row) for row in reader if (row.get(column) or '').upper() in bad_values]

        problems = []
        if _changed:
            problems.append('Integer-only export prices differ from source; manual price approval required')
        problems += problem_rows('QUALITY REPORT', {'ERROR', 'WARNING'}, 'severity')
        problems += problem_rows('PRICE AUDIT', {'REVIEW', 'MISMATCH'}, 'status')
        problems += problem_rows('STOREFRONT AUDIT', {'REVIEW', 'RATE_LIMITED'}, 'status')
        # Early stop after throttling leaves other fractional products unverified.
        storefront_report = staging / (safe + ' - STOREFRONT AUDIT.csv')
        quality_report = staging / (safe + ' - QUALITY REPORT.csv')
        if storefront_report.is_file() and quality_report.is_file():
            with storefront_report.open(encoding='utf-8-sig', newline='') as fh:
                audited_urls = {row.get('product_url') for row in csv.DictReader(fh)}
            with quality_report.open(encoding='utf-8-sig', newline='') as fh:
                fractional_urls = {row.get('source_url') for row in csv.DictReader(fh)
                                   if row.get('issue_code') in
                                   ('FRACTIONAL_PKR_PRICE', 'FRACTIONAL_PRICE_DISPLAY_MATCH')}
            if fractional_urls - audited_urls:
                problems.append('Storefront verification incomplete after rate limiting')

        # Do not publish a partial/uncertain catalog if the source hit its known page limit.
        if any('Catalog completeness NOT PROVEN' in line for line in logs):
            problems.append('Catalog completeness unverified')
        audit_dir.mkdir(parents=True, exist_ok=True)
        for report in staging.glob(safe + ' - *.csv'):
            shutil.copy2(report, audit_dir / report.name)
        if any('multi-selector importer and combination mapping' in line for line in logs):
            problems.append('Multi-selector importer compatibility not verified')
        if problems:
            shutil.copy2(review_file, audit_dir / review_file.name)
            # CHOTUAPP_VISIBLE_REVIEW_V1
            # A completed extraction must remain visible even when FINAL is blocked.
            # Never overwrite a prior REVIEW without preserving a timestamped backup.
            visible_review = real_out / (safe + ' - REVIEW.xlsx')
            if visible_review.exists():
                review_backups = software_dir / 'review_backups'
                review_backups.mkdir(parents=True, exist_ok=True)
                stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
                shutil.copy2(visible_review, review_backups / (safe + ' - REVIEW - ' + stamp + '.xlsx'))
            with tempfile.NamedTemporaryFile(prefix='.' + safe + '-review-', suffix='.xlsx',
                                             dir=str(real_out), delete=False) as tmp_file:
                review_tmp = Path(tmp_file.name)
            try:
                shutil.copy2(review_file, review_tmp)
                check_wb = load_workbook(review_tmp, read_only=True)
                try:
                    if check_wb['Products'].max_row < 2:
                        raise RuntimeError('REVIEW workbook has no products')
                finally:
                    check_wb.close()
                os.replace(review_tmp, visible_review)
            finally:
                review_tmp.unlink(missing_ok=True)
            log('SAVED REVIEW EXCEL: ' + str(visible_review))
            progress(min(current_progress, 96), 'REVIEW REQUIRED: FINAL preserved')
            log('REVIEW REQUIRED: ' + str(len(problems)) + ' audit issue(s). Previous FINAL kept.')
            log('Review files: ' + str(audit_dir))
            return

        # Never overwrite the last good FINAL without a separate backup.
        if final.exists():
            backups = software_dir / 'final_backups'
            backups.mkdir(parents=True, exist_ok=True)
            stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            shutil.copy2(final, backups / (safe + ' - FINAL - ' + stamp + '.xlsx'))
        tmp = real_out / ('.' + safe + ' - FINAL.building.xlsx')
        try:
            shutil.copy2(review_file, tmp)
            os.replace(tmp, final)
        finally:
            if tmp.exists():
                tmp.unlink()
        progress(100, 'COMPLETED: ' + name)
        log('COMPLETED: ' + str(final))
        log('One Excel in output for this store. Audit reports: ' + str(audit_dir))
        log('NOTE: Excel structure passed local checks; live importer/checkout compatibility still unverified.')
    except Exception:
        progress(current_progress, 'FAILED: ' + name)
        raise
    finally:
        OUT = real_out
        shutil.rmtree(staging, ignore_errors=True)


class App:
    def __init__(self,root):
        self.root=root; root.title('ChotuApp Data Extractor v2'); root.geometry('950x780')
        self.events=queue.Queue(); self.sites=[]
        try: self.sites=json.loads(CONFIG.read_text(encoding='utf-8'))
        except (OSError,ValueError): pass
        frame=ttk.Frame(root,padding=14); frame.pack(fill='both',expand=True)
        ttk.Label(frame,text='ChotuApp Data Extractor v2',font=('Segoe UI',18,'bold')).pack(anchor='w')
        ttk.Label(frame,text='Shopify public catalogs → ChotuApp Excel | Save template once, then Refresh').pack(anchor='w',pady=(0,12))
        row=ttk.Frame(frame); row.pack(fill='x')
        ttk.Label(row,text='Template:').pack(side='left')
        self.template=tk.StringVar(value=str(HOME/'ChotuApp_Seller_Template_Updated_Variants.xlsx'))
        ttk.Entry(row,textvariable=self.template).pack(side='left',fill='x',expand=True,padx=6)
        ttk.Button(row,text='Browse',command=self.browse).pack(side='left')
        row=ttk.Frame(frame); row.pack(fill='x',pady=10)
        self.name=tk.StringVar(); self.url=tk.StringVar()
        ttk.Entry(row,textvariable=self.name,width=22).pack(side='left',padx=(0,5)); self.name.set('Brand name')
        ttk.Entry(row,textvariable=self.url).pack(side='left',fill='x',expand=True,padx=5); self.url.set('https://example.com')
        ttk.Button(row,text='Add Website',command=self.add).pack(side='left')
        ttk.Label(frame,text='Bulk add: paste 10 or more website URLs below (one per line; optional Brand | URL)').pack(anchor='w')
        self.bulk=tk.Text(frame,height=3,wrap='none'); self.bulk.pack(fill='x',pady=(3,4))
        ttk.Button(frame,text='Add All Websites',command=self.add_bulk).pack(anchor='w',pady=(0,8))
        # CHOTUAPP_LIVE_STATUS_V1 — small indicator beside the website list
        status_row=ttk.Frame(frame)
        status_row.pack(fill='x',pady=(0,3))
        self.live_status=tk.Label(status_row,text='● READY',fg='#65717c',font=('Segoe UI',10,'bold'))
        self.live_status.pack(side='right',padx=(6,8))
        self.live_spinner=ttk.Progressbar(status_row,mode='indeterminate',length=58)
        self.live_spinner.pack(side='right',padx=(0,2))
        self.live_spinner.pack_forget()
        self.job_failed=False
        self.job_completed=0
        self.job_expected=0
        self.list=tk.Listbox(frame,height=6); self.list.pack(fill='x')
        row=ttk.Frame(frame); row.pack(fill='x',pady=8)
        self.refresh=ttk.Button(row,text='Refresh All',command=self.start); self.refresh.pack(side='left')
        self.refresh_selected=ttk.Button(row,text='Refresh Selected',command=self.start_selected); self.refresh_selected.pack(side='left',padx=8)
        self.pause_button=ttk.Button(row,text='⏸ Pause',command=self.toggle_pause,state='disabled'); self.pause_button.pack(side='left',padx=8)
        ttk.Button(row,text='Remove Selected',command=self.remove).pack(side='left',padx=8)
        ttk.Button(row,text='Open Output Folder',command=lambda:os.startfile(str(OUT))).pack(side='left')
        ttk.Label(frame,text='SAFETY: Refresh writes REVIEW Excel + CHANGE REPORT; verified FINAL files are never overwritten automatically.').pack(anchor='w')
        # CHOTUAPP_VISIBLE_SIDE_MONITOR_V2
        # Split the lower work area so diagnostics never disappear below the window.
        monitor_area = ttk.PanedWindow(frame, orient='horizontal')
        monitor_area.pack(fill='both', expand=True, pady=(4, 0))
        main_console = ttk.Frame(monitor_area)
        side_console = ttk.LabelFrame(monitor_area, text='LIVE CODE MONITOR')
        monitor_area.add(main_console, weight=3)
        monitor_area.add(side_console, weight=2)
        self.logbox=tk.Text(main_console,height=13,wrap='word',font=('Consolas',9))
        self.logbox.pack(fill='both',expand=True)
        self._chotu_side_console = side_console
        self._chotu_monitor_area = monitor_area
        self.progress_value=tk.IntVar(value=0)
        self.progress_bar=ttk.Progressbar(frame,mode='determinate',maximum=100,variable=self.progress_value)
        self.progress_bar.pack(fill='x',pady=(8,3))
        self.progress_label=ttk.Label(frame,text='Ready — 0%')
        self.progress_label.pack(anchor='w')
        # Debug panel stays visible while extraction is running.
        self.debug_file = Path(__file__).resolve().parent / 'debug_logs' / 'live_debug.log'
        self.debug_file.parent.mkdir(parents=True, exist_ok=True)
        debug_frame = self._chotu_side_console
        self.debug_status = ttk.Label(debug_frame, text='Idle')
        self.debug_status.pack(anchor='w')
        self.debug_box = tk.Text(debug_frame, height=13, wrap='word', font=('Consolas', 9))
        self.debug_box.pack(fill='both', expand=True)
        actions = ttk.Frame(debug_frame); actions.pack(fill='x')
        ttk.Button(actions, text='Copy Debug Log', command=self.copy_debug).pack(side='left')
        ttk.Button(actions, text='Open Debug Folder', command=lambda: os.startfile(str(self.debug_file.parent))).pack(side='left', padx=8)
        self.root.after(1000, self.debug_watchdog)
        self.redraw(); self.root.after(100,self.poll)
    def copy_debug(self):
        try:
            text = self.debug_file.read_text(encoding='utf-8') if self.debug_file.exists() else self.debug_box.get('1.0', 'end-1c')
        except OSError:
            text = self.debug_box.get('1.0', 'end-1c')
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.debug_status.config(text='Debug log copied (visible lines)')

    def debug_watchdog(self):
        try:
            with _chotu_debug_lock:
                state = dict(_chotu_debug_state)
            if state['request'] and state['started']:
                elapsed = int(time.monotonic() - state['started'])
                self.debug_status.config(text='STAGE: ' + state['stage'] + ' | HTTP ' + str(elapsed) + 's')
                self._chotu_last_request = state['request']
            else:
                self.debug_status.config(text='STAGE: ' + state['stage'] + ' | HTTP idle')
            if not hasattr(self, '_chotu_last_watchdog_stage') or self._chotu_last_watchdog_stage != state['stage']:
                self._chotu_last_watchdog_stage = state['stage']
                self.debug_box.insert('end', '[MONITOR] Stage: ' + state['stage'] + '\n')
                self.debug_box.see('end')
        finally:
            self.root.after(2000, self.debug_watchdog)

    def set_live_status(self, state, detail=''):
        if state == 'working':
            self.live_status.config(text='● WORKING' + (' — '+detail if detail else ''),fg='#1765ad')
            self.live_spinner.pack(side='right',before=self.live_status,padx=(0,2))
            self.live_spinner.start(12)
        else:
            self.live_spinner.stop()
            self.live_spinner.pack_forget()
            color = '#16803c' if state == 'completed' else '#c62828'
            word = '● COMPLETED' if state == 'completed' else '● ERROR'
            self.live_status.config(text=word + (' — '+detail if detail else ''),fg=color)

    @staticmethod
    def _output_snapshot(name):
        safe = re.sub(r'[^\w .-]', '', name).strip() or 'Shopify'
        result = {}
        for suffix in (' - REVIEW.xlsx',' - FINAL.xlsx'):
            file = OUT / (safe + suffix)
            if file.is_file():
                stat = file.stat()
                result[str(file)] = (stat.st_mtime_ns, stat.st_size)
        return result

    def _run_checked(self, site, template):
        global _chotu_debug_sink
        name = site['name']
        _chotu_debug_sink = lambda line: self.events.put(('__DEBUG__', line))
        _chotu_debug_stage('Starting ' + name)
        checkpoint_opened = False
        success = False
        try:
            cp = _chotu_open_checkpoint(site['url'], name)
            checkpoint_opened = True
            self.events.put('CHECKPOINT: ' + str(cp) + ' (successful API pages reusable after restart)')
            before = self._output_snapshot(name)
            evidence = []
            def log_line(line):
                evidence.append(str(line))
                self.events.put(line)
            run_site(site['url'], name, template, log_line)
            after = self._output_snapshot(name)
            saved = any(after[k] != before.get(k) for k in after)
            announced = any('SAVED REVIEW EXCEL:' in x or x.startswith('COMPLETED: ') for x in evidence)
            if not saved or not announced:
                raise RuntimeError('New Excel was not confirmed in ANAS_DATA_FETCH')
            success = True
            self.events.put(('__JOB_RESULT__', True, name))
        except Exception as exc:
            _chotu_debug('EXCEPTION: ' + repr(exc))
            _chotu_debug(_chotu_traceback.format_exc())
            self.events.put('FAILED: ' + name + ': ' + str(exc))
            self.events.put(('__JOB_RESULT__', False, name))
        finally:
            if checkpoint_opened:
                _chotu_close_checkpoint(success=success)
            _chotu_debug_stage('Idle')
            _chotu_debug_sink = None

    def toggle_pause(self):
        if _chotu_pause_gate.is_set():
            _chotu_pause_gate.clear()
            self.pause_button.config(text='▶ Resume')
            self.set_live_status('working', 'PAUSE REQUESTED — waiting for safe point')
            self.logbox.insert('end', 'PAUSE REQUESTED: will stop at next safe checkpoint; an in-flight HTTP request may finish first.\n')
        else:
            _chotu_pause_gate.set()
            self.pause_button.config(text='⏸ Pause')
            self.set_live_status('working', 'RESUMED')
            self.logbox.insert('end', 'RESUMED: continuing from saved request checkpoint.\n')

    def browse(self):
        path=filedialog.askopenfilename(filetypes=[('Excel template','*.xlsx')]);
        if path:self.template.set(path)
    def redraw(self):
        self.list.delete(0,'end')
        for x in self.sites:self.list.insert('end',f"{x['name']}    |    {x['url']}")
    def save(self): CONFIG.write_text(json.dumps(self.sites,indent=2),encoding='utf-8')
    def add(self):
        name=self.name.get().strip(); url=self.url.get().strip().rstrip('/')
        p=urlparse(url)
        if not name or name=='Brand name' or p.scheme not in ('http','https') or not p.netloc:
            messagebox.showerror('Invalid input','Enter a brand name and full https:// website URL');return
        if any(x['url']==url for x in self.sites):messagebox.showwarning('Duplicate','Website already added');return
        self.sites.append({'name':name,'url':url});self.save();self.redraw()
    def add_bulk(self):
        lines=self.bulk.get('1.0','end').splitlines()
        added=0; skipped=[]
        existing={x['url'].lower() for x in self.sites}
        for line in lines:
            line=line.strip()
            if not line:continue
            if '|' in line:
                name,url=[part.strip() for part in line.split('|',1)]
            else:
                url=line
                if not url.startswith(('https://','http://')):url='https://'+url
                host=urlparse(url).netloc.lower().removeprefix('www.')
                name=host.split('.')[0].replace('-',' ').title()
            url=url.rstrip('/')
            parsed=urlparse(url)
            if parsed.scheme not in ('https','http') or not parsed.hostname or not name:
                skipped.append(line);continue
            if url.lower() in existing:
                skipped.append(line);continue
            self.sites.append({'name':name,'url':url})
            existing.add(url.lower());added+=1
        if added:self.save();self.redraw();self.bulk.delete('1.0','end')
        messagebox.showinfo('Bulk Add',f'Added: {added}\nSkipped/duplicates: {len(skipped)}')
    def remove(self):
        sel=self.list.curselection()
        if sel:self.sites.pop(sel[0]);self.save();self.redraw()
    def start_selected(self):
        if str(self.refresh['state']) == 'disabled': return
        sel = self.list.curselection()
        if not sel:
            messagebox.showwarning('Select website', 'Please select one website from the list first.')
            return
        template = self.template.get()
        if not Path(template).is_file():
            messagebox.showerror('Template missing', 'Choose your original ChotuApp template XLSX')
            return
        site = dict(self.sites[sel[0]])
        self.refresh.config(state='disabled')
        self.refresh_selected.config(state='disabled')
        self.refresh_selected.config(state='disabled')
        self.logbox.delete('1.0', 'end')
        self.progress_value.set(0); self.progress_label.config(text='Starting — 0%')
        _chotu_pause_gate.set()
        self.pause_button.config(state='normal',text='⏸ Pause')
        self.job_failed=False; self.job_completed=0; self.job_expected=1
        self.set_live_status('working',site['name'])
        def worker():
            self.events.put('REFRESH SELECTED: ' + site['name'] + ' - ' + site['url'])
            self._run_checked(site, template)
            self.events.put('__DONE__')
        threading.Thread(target=worker, daemon=True).start()
    def start(self):
        if str(self.refresh['state']) == 'disabled': return
        template=self.template.get()
        if not Path(template).is_file():messagebox.showerror('Template missing','Choose your original ChotuApp template XLSX');return
        if not self.sites:messagebox.showerror('No websites','Add a website first');return
        self.refresh.config(state='disabled')
        self.refresh_selected.config(state='disabled')
        self.logbox.delete('1.0','end')
        self.progress_value.set(0); self.progress_label.config(text='Starting — 0%')
        _chotu_pause_gate.set()
        self.pause_button.config(state='normal',text='⏸ Pause')
        self.job_failed=False; self.job_completed=0; self.job_expected=len(self.sites)
        self.set_live_status('working',str(len(self.sites))+' stores')
        def worker():
            for x in list(self.sites):
                self.events.put(f"\nREFRESH: {x['name']} — {x['url']}")
                self._run_checked(x, template)
            self.events.put('__DONE__')
        threading.Thread(target=worker,daemon=True).start()
    def poll(self):
        try:
            while True:
                msg=self.events.get_nowait()
                if msg=='__DONE__':
                    if self.job_failed or self.job_completed != self.job_expected:
                        self.set_live_status('error','Excel missing / failed')
                        self.progress_label.config(text='ERROR — check log; close open Excel files')
                    else:
                        self.set_live_status('completed','Excel saved')
                        self.progress_label.config(text='Completed — Excel saved (REVIEW/FINAL as logged)')
                    self.refresh.config(state='normal')
                    self.refresh_selected.config(state='normal')
                    self.pause_button.config(state='disabled',text='⏸ Pause')
                    _chotu_pause_gate.set()
                elif isinstance(msg,tuple) and len(msg)==3 and msg[0]=='__JOB_RESULT__':
                    _,ok,site_name=msg
                    self.job_completed += 1
                    if not ok:
                        self.job_failed=True
                        self.set_live_status('working','error in '+site_name)
                elif isinstance(msg,tuple) and len(msg)==2 and msg[0]=='__DEBUG__':
                    line = msg[1]
                    self.debug_box.insert('end', line + '\n')
                    if int(self.debug_box.index('end-1c').split('.')[0]) > 800:
                        self.debug_box.delete('1.0', '201.0')
                    self.debug_box.see('end')
                    try:
                        with self.debug_file.open('a', encoding='utf-8') as fh:
                            fh.write(line + '\n')
                    except OSError:
                        pass
                elif isinstance(msg,str) and msg.startswith('__CHOTU_PROGRESS__|'):
                    _,pct,detail=msg.split('|',2)
                    self.progress_value.set(int(pct))
                    self.progress_label.config(text=f'{detail} — {pct}%')
                else:self.logbox.insert('end',msg+'\n');self.logbox.see('end')
        except queue.Empty:pass
        self.root.after(100,self.poll)

if __name__=='__main__':
    root=tk.Tk();App(root);root.mainloop()
